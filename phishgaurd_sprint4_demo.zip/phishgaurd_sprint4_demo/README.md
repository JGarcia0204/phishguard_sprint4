# PhishGuard – Sprint 2 Demo

This minimal FastAPI project demonstrates exactly what Sprint 2 is about:

- Short phishing quiz + **save progress** (auto-save per question)
- One-tap **Report Phish** -> creates a **simulated ticket**
- **Admin dashboard** with counts (reports & quiz completions)
- **CSV export** (`/api/admin/export.csv`)
- **Privacy page** stating demo-only, no real PII

> Stack chosen per charter constraints: Python FastAPI backend + very simple HTML/CSS/JS frontend (no build step).

## Run

```bash

# This gets you the proper package installer to ensure the correct packages are installed
python get-pip.py

# Make sure you are in the correct file path where the program is stored to execute properly
cd <file path>

# Install deps
pip install fastapi uvicorn "jinja2" "pydantic<2" "python-multipart"

# Start the server
uvicorn main:app --reload --port 8000

# 3) Open the demo
# Home/Quiz:    http://127.0.0.1:8000/
# Admin:        http://127.0.0.1:8000/admin
# Privacy:      http://127.0.0.1:8000/privacy
```

## Endpoints

- `GET /api/quiz` – returns quiz data
- `GET /api/progress?quiz_id=...` – load progress
- `POST /api/progress` – save progress (`{"quiz_id": "...", "last_index": 0}`)
- `POST /api/completion` – record completion (`{"quiz_id":"...","score":x,"total":y}`)
- `POST /api/report` – log a simulated ticket (`{"source":"email","note":"..."}`)
- `GET /api/admin/metrics` – totals for admin cards
- `GET /api/admin/export.csv` – CSV export

## Notes

- **No real PII** stored; demo-only. A simple cookie-based `user_id` of `"guest"` is used.
- SQLite DB file `phishguard.db` is created on first run.
- This matches Sprint 2 scope: quiz + reporting + admin counts + CSV + privacy page.