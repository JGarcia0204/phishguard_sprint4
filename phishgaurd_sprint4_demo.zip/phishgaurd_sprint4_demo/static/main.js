// PhishGuard Sprint 4 main.js – fixed correct/incorrect mapping + working score

async function fetchJSON(url, opts = {}) {
  const res = await fetch(
    url,
    Object.assign({ headers: { "Content-Type": "application/json" } }, opts)
  );
  if (!res.ok) throw new Error("Request failed");
  return res.json();
}

// ---------- QUIZ ----------
const quizEl = document.getElementById("quiz");
if (quizEl) {
  let quizData = null;
  let idx = 0;
  let score = 0;
  const answered = new Map();
  const correctAnswers = new Set(); // track which questions were answered correctly

  const titleEl = document.getElementById("quiz-title");
  const progressEl = document.getElementById("quiz-progress");
  const questionEl = document.getElementById("quiz-question");
  const choicesEl = document.getElementById("quiz-choices");
  const prevBtn = document.getElementById("prev-btn");
  const nextBtn = document.getElementById("next-btn");
  const submitBtn = document.getElementById("submit-btn");
  const resultEl = document.getElementById("quiz-result");

  function clearChoiceStyles() {
    choicesEl.querySelectorAll("button.choice-btn").forEach((b) => {
      b.classList.remove("selected", "correct", "incorrect");
      b.setAttribute("aria-checked", "false");
    });
  }

  function render() {
    if (!quizData) return;
    const q = quizData.questions[idx];
    titleEl.textContent = quizData.title;
    progressEl.textContent = `Q ${idx + 1} / ${quizData.questions.length}`;
    questionEl.textContent = q.q;
    choicesEl.innerHTML = "";

    q.choices.forEach((c, i) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "choice-btn";
      btn.textContent = c;
      btn.dataset.choiceIndex = String(i);
      btn.onclick = () => {
        answered.set(idx, i);
        saveProgress(idx);
        clearChoiceStyles();
        btn.classList.add("selected");
        btn.setAttribute("aria-checked", "true");
        nextBtn.disabled = true; // reset next until they answer correctly again
      };
      choicesEl.appendChild(btn);
    });

    const prevAns = answered.get(idx);
    if (prevAns !== undefined) {
      const preBtn = choicesEl.querySelector(
        `button.choice-btn[data-choice-index="${prevAns}"]`
      );
      if (preBtn) {
        preBtn.classList.add("selected");
        preBtn.setAttribute("aria-checked", "true");
      }
    }

    prevBtn.disabled = idx === 0;
    nextBtn.disabled = !correctAnswers.has(idx); // unlock only if previously correct
  }

  async function load() {
    quizData = await fetchJSON("/api/quiz");
    try {
      const prog = await fetchJSON(
        `/api/progress?quiz_id=${encodeURIComponent(quizData.quiz_id)}`
      );
      idx = prog.last_index || 0;
    } catch {}
    render();
  }

  async function saveProgress(currentIndex) {
    try {
      await fetchJSON("/api/progress", {
        method: "POST",
        body: JSON.stringify({
          quiz_id: quizData.quiz_id,
          last_index: currentIndex,
        }),
      });
    } catch (e) {
      console.warn("progress save failed", e);
    }
  }

  prevBtn.onclick = () => {
    if (idx > 0) {
      idx--;
      render();
    }
  };

  nextBtn.onclick = () => {
    if (idx < quizData.questions.length - 1) {
      idx++;
      render();
    }
  };

  // ---------- Submit: show selected answer red/green + unlock next on correct ----------
  submitBtn.onclick = async () => {
    if (!quizData) return;

    // Remove old highlights
    document.querySelectorAll(".choice-btn").forEach((b) => {
      b.classList.remove("correct", "incorrect");
    });

    const q = quizData.questions[idx];
    const ans = answered.get(idx);
    const correctIndex = Number(q.answer); // FIXED: no -1 subtraction (answers are 0-based)

    if (ans !== undefined) {
      const choiceBtn = document.querySelector(
        `#quiz-choices button.choice-btn[data-choice-index="${ans}"]`
      );

      if (choiceBtn) {
        if (ans === correctIndex) {
          // ✅ Correct
          choiceBtn.classList.add("correct");
          correctAnswers.add(idx);
          nextBtn.disabled = false;
        } else {
          // ❌ Incorrect
          choiceBtn.classList.add("incorrect");
          nextBtn.disabled = true;
        }
      }
    }

    // Update score dynamically
    score = correctAnswers.size;
    resultEl.textContent = `Score: ${score} / ${quizData.questions.length}`;

    try {
      await fetchJSON("/api/completion", {
        method: "POST",
        body: JSON.stringify({
          quiz_id: quizData.quiz_id,
          score,
          total: quizData.questions.length,
        }),
      });
    } catch (e) {
      console.warn("completion failed", e);
    }
  };

  load();
}

// ---------- REPORT ----------
const reportBtn = document.getElementById("report-btn");
if (reportBtn) {
  const noteEl = document.getElementById("report-note");
  const statusEl = document.getElementById("report-status");
  reportBtn.onclick = async () => {
    try {
      const res = await fetchJSON("/api/report", {
        method: "POST",
        body: JSON.stringify({ source: "email", note: noteEl.value || "" }),
      });
      statusEl.textContent = res.message || "Reported";
      noteEl.value = "";
    } catch {
      statusEl.textContent = "Failed to report (demo).";
    }
  };
}

// ---------- ADMIN METRICS ----------
const refreshBtn = document.getElementById("refresh-metrics");
if (refreshBtn) {
  const reportsTotal = document.getElementById("reports-total");
  const completionsTotal = document.getElementById("completions-total");
  const loadMetrics = async () => {
    try {
      const m = await fetchJSON("/api/admin/metrics");
      reportsTotal.textContent = m.reports;
      completionsTotal.textContent = m.quiz_completions;
    } catch {
      reportsTotal.textContent = "-";
      completionsTotal.textContent = "-";
    }
  };
  refreshBtn.onclick = loadMetrics;
  loadMetrics();
}
