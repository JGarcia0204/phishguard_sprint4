from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse, StreamingResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from typing import Optional
from datetime import datetime
import io
import csv
import sqlite3
import os

# ---------- App branding (Sprint 4) ----------
app = FastAPI(title="PhishGuard Sprint 4 Demo")

# ---------- SQLite setup ----------
DB_PATH = os.path.join(os.path.dirname(__file__), "phishguard.db")

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS quiz_progress (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT,
            quiz_id TEXT,
            last_index INTEGER,
            updated_at TEXT
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT,
            source TEXT,
            note TEXT,
            created_at TEXT
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS quiz_completions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT,
            quiz_id TEXT,
            score INTEGER,
            total INTEGER,
            completed_at TEXT
        )
    """)
    conn.commit()
    conn.close()

init_db()

# ---------- Static & Templates ----------
app.mount("/static", StaticFiles(directory=os.path.join(os.path.dirname(__file__), "static")), name="static")
templates = Jinja2Templates(directory=os.path.join(os.path.dirname(__file__), "templates"))

# ---------- Simple cookie-based user handling ----------
def get_user_id(request: Request) -> str:
    return request.cookies.get("user_id", "guest")

def is_admin(request: Request) -> bool:
    return request.cookies.get("user_role") == "admin"

# ---------- Quiz data (Sprint 4: +5 new questions & title) ----------
QUIZ = {
    "quiz_id": "phishing_basics_v2",
    "title": "Phishing Awareness (Basics) – Sprint 4",
    "questions": [
        {"q": "You receive an email with a suspicious link asking you to verify your password. What should you do first?",
         "choices": ["Click the link quickly", "Hover over the link to inspect URL", "Forward to everyone", "Reply with your password"], "answer": 1},
        {"q": "The sender address looks odd (e.g., support@micr0s0ft.com). This is a sign of:",
         "choices": ["Legit email", "Phishing", "Newsletter", "Internal IT"], "answer": 1},
        {"q": "Attachments with unexpected .exe files are:",
         "choices": ["Usually fine", "Best opened on mobile", "Potentially dangerous", "Guaranteed safe"], "answer": 2},
        {"q": "A quick way to report a suspected phish in this demo is:",
         "choices": ["Ignore it", "Use the 'Report Phish' button", "Email your password", "Open the attachment"], "answer": 1},
        {"q": "Strong indicators of phishing include:",
         "choices": ["Urgency and threats", "Typos and odd domains", "Unexpected links/attachments", "All of the above"], "answer": 3},
        {"q": "You receive a message from your boss asking for gift cards urgently. What should you do?",
         "choices": ["Buy them immediately", "Call your boss directly to confirm", "Reply to the email with codes", "Forward it to HR"], "answer": 1},
        {"q": "A website you opened doesn’t have HTTPS in the URL bar. What should you assume?",
         "choices": ["It’s secure", "It might not be safe for sensitive info", "HTTPS isn’t needed", "It’s always legitimate"], "answer": 1},
        {"q": "You notice a fake company logo and odd grammar in an email. What does this suggest?",
         "choices": ["Official message", "Phishing attempt", "New branding", "Automated system update"], "answer": 1},
        {"q": "A pop-up claims your computer is infected and asks to install software. What should you do?",
         "choices": ["Click install", "Ignore or close the window", "Call the number shown", "Enter your credentials"], "answer": 1},
        {"q": "Before clicking a link in a text message from your bank, you should:",
         "choices": ["Click it to verify quickly", "Ignore it and log in directly on the official app or site", "Forward to friends", "Send your password via text"], "answer": 1},

        # ---- Sprint 4: five new questions ----
        {"q": "You get a friend request from a coworker you already have on social media. What’s the safest action?",
         "choices": ["Accept again", "Ignore or verify with them directly", "Share your info to confirm", "Click their profile link"], "answer": 1},
        {"q": "You’re asked to enter credentials into a pop-up on a familiar-looking website. What should you do?",
         "choices": ["Enter details", "Check the URL before entering anything", "Close the site immediately", "Screenshot and post online"], "answer": 1},
        {"q": "A link promises a free gift if you log in with your email. This is most likely:",
         "choices": ["A secure promotion", "A phishing scam", "A survey", "A bonus offer"], "answer": 1},
        {"q": "If an email claims to be urgent but contains typos and odd grammar, it’s likely:",
         "choices": ["Internal notice", "Phishing attempt", "Spam ad", "Official alert"], "answer": 1},
        {"q": "When unsure about an email’s legitimacy, the safest step is to:",
         "choices": ["Click links to confirm", "Report it", "Delete immediately", "Call IT or verify sender directly"], "answer": 3}
    ]
}

# ---------- Models ----------
class ProgressIn(BaseModel):
    quiz_id: str
    last_index: int

class CompletionIn(BaseModel):
    quiz_id: str
    score: int
    total: int

class ReportIn(BaseModel):
    source: str = "email"
    note: Optional[str] = ""

# ---------- Pages ----------
@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request, "title": "PhishGuard – Sprint 4 Demo"})

@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request, "title": "Login – PhishGuard"})

# Sprint 4: credential-based admin login (env overrides supported)
ADMIN_USER = os.getenv("PG_ADMIN_USER", "admin")
ADMIN_PASS = os.getenv("PG_ADMIN_PASS", "phishguard123")

@app.post("/login")
def do_login(username: str = Form(...), password: str = Form(...)):
    response = RedirectResponse(url="/", status_code=302)
    if username == ADMIN_USER and password == ADMIN_PASS:
        response.set_cookie(key="user_role", value="admin", httponly=True, samesite="lax")
        response.set_cookie(key="user_id", value="admin_user", httponly=True, samesite="lax")
    else:
        # Treat everything else as guest
        response.set_cookie(key="user_role", value="guest", httponly=True, samesite="lax")
        response.set_cookie(key="user_id", value="guest", httponly=True, samesite="lax")
    return response

@app.get("/logout")
def logout():
    response = RedirectResponse(url="/")
    response.delete_cookie("user_role")
    response.delete_cookie("user_id")
    return response

@app.get("/admin", response_class=HTMLResponse)
def admin(request: Request):
    if not is_admin(request):
        return HTMLResponse("Not authorized", status_code=403)
    return templates.TemplateResponse("admin.html", {"request": request, "title": "Admin Dashboard – PhishGuard"})

@app.get("/privacy", response_class=HTMLResponse)
def privacy(request: Request):
    return templates.TemplateResponse("privacy.html", {"request": request, "title": "Privacy – PhishGuard"})

# ---------- API routes ----------
@app.get("/api/quiz")
def get_quiz():
    return QUIZ

@app.post("/api/progress")
def save_progress(data: ProgressIn, request: Request):
    user_id = get_user_id(request)
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT id FROM quiz_progress WHERE user_id=? AND quiz_id=?", (user_id, data.quiz_id))
    row = cur.fetchone()
    now = datetime.utcnow().isoformat()
    if row:
        cur.execute("UPDATE quiz_progress SET last_index=?, updated_at=? WHERE id=?", (data.last_index, now, row["id"]))
    else:
        cur.execute("INSERT INTO quiz_progress (user_id, quiz_id, last_index, updated_at) VALUES (?, ?, ?, ?)",
                    (user_id, data.quiz_id, data.last_index, now))
    conn.commit()
    conn.close()
    return {"status": "ok"}

@app.get("/api/progress")
def load_progress(request: Request, quiz_id: str):
    user_id = get_user_id(request)
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT last_index FROM quiz_progress WHERE user_id=? AND quiz_id=?", (user_id, quiz_id))
    row = cur.fetchone()
    conn.close()
    return {"quiz_id": quiz_id, "last_index": row["last_index"] if row else 0}

@app.post("/api/completion")
def record_completion(data: CompletionIn, request: Request):
    user_id = get_user_id(request)
    conn = get_db()
    cur = conn.cursor()
    cur.execute("INSERT INTO quiz_completions (user_id, quiz_id, score, total, completed_at) VALUES (?, ?, ?, ?, ?)",
                (user_id, data.quiz_id, data.score, data.total, datetime.utcnow().isoformat()))
    conn.commit()
    conn.close()
    return {"status": "ok"}

@app.post("/api/report")
def report_phish(data: ReportIn, request: Request):
    user_id = get_user_id(request)
    conn = get_db()
    cur = conn.cursor()
    cur.execute("INSERT INTO reports (user_id, source, note, created_at) VALUES (?, ?, ?, ?)",
                (user_id, data.source, data.note or "", datetime.utcnow().isoformat()))
    conn.commit()
    conn.close()
    return {"status": "ok", "message": "Report logged (demo ticket created)."}

@app.get("/api/admin/metrics")
def admin_metrics(request: Request):
    if not is_admin(request):
        return JSONResponse({"detail": "Not authorized"}, status_code=403)
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) AS c FROM reports")
    reports = cur.fetchone()["c"]
    cur.execute("SELECT COUNT(*) AS c FROM quiz_completions")
    completions = cur.fetchone()["c"]
    conn.close()
    return {"reports": reports, "quiz_completions": completions}

@app.get("/api/admin/export.csv")
def export_csv(request: Request):
    if not is_admin(request):
        return PlainTextResponse("Not authorized", status_code=403)
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) AS c FROM reports")
    reports = cur.fetchone()["c"]
    cur.execute("SELECT COUNT(*) AS c FROM quiz_completions")
    completions = cur.fetchone()["c"]
    conn.close()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["date", "total_reports", "total_quiz_completions"])
    writer.writerow([datetime.utcnow().isoformat(), reports, completions])
    csv_bytes = io.BytesIO(output.getvalue().encode("utf-8"))
    headers = {"Content-Disposition": "attachment; filename=metrics.csv"}
    return StreamingResponse(csv_bytes, media_type="text/csv", headers=headers)

@app.get("/healthz")
def health():
    return {"ok": True}
